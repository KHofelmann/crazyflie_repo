def main():
    print('Hi from optitrack_core.')


if __name__ == '__main__':
    main()

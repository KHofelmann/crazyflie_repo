def main():
    print('Hi from controller_core.')


if __name__ == '__main__':
    main()
